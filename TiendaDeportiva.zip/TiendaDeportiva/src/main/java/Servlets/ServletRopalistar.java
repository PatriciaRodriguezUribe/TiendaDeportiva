
package Servlets;

import Controller.RopaController;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hp
 */
@WebServlet(name = "ServletRopalistar", urlPatterns = {"/ServletRopalistar"})
public class ServletRopalistar extends HttpServlet {
   
    
    private static final long serialVersionUID = 1L;
    public ServletRopalistar(){
        super();

    }     
        
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        RopaController Ropa = new RopaController();
        boolean ordenar = Boolean.parseBoolean(request.getParameter("ordenar"));
        String orden = request.getParameter("orden");
        String RopaStr = Ropa.listarRopa(ordenar, orden);
        PrintWriter out = response.getWriter();
        out.println(RopaStr);
        out.flush();
        out.close();

       
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

 
   

}
