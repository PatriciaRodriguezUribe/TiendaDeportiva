
package Beans;


public class usuarios {
    private String username;
    private String contrasena;
    private String Nombre;
    private String Apellido;
    private String email;
    private double cuenta_saldo;
    private boolean bonos;

    public usuarios(String username, String contrasena, String Nombre, String Apellido, String email, double cuenta_saldo, boolean bonos) {
        this.username = username;
        this.contrasena = contrasena;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.email = email;
        this.cuenta_saldo = cuenta_saldo;
        this.bonos = bonos;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getCuenta_saldo() {
        return cuenta_saldo;
    }

    public void setCuenta_saldo(double cuenta_saldo) {
        this.cuenta_saldo = cuenta_saldo;
    }

    public boolean isBonos() {
        return bonos;
    }

    public void setBonos(boolean bonos) {
        this.bonos = bonos;
    }

    @Override
    public String toString() {
        return "usuario{" + "username=" + username + ", contrasena=" + contrasena + ", Nombre=" + Nombre + ", Apellido=" + Apellido + ", email=" + email + ", cuenta_saldo=" + cuenta_saldo + ", bonos=" + bonos + '}';
    }

   

    

    

}
