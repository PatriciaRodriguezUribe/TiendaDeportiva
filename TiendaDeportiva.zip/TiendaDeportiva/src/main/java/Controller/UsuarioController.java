package Controller;

import Beans.usuarios;
import java.sql.ResultSet;
import java.sql.Statement;
import Connection.DBConnection;
import com.google.gson.Gson;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Date;

public class UsuarioController implements IUsuarioController {

@Override
public String login(String username, String contrasena){
     Gson gson= new Gson();
     DBConnection con = new DBConnection();
    
    String sql = "SELECT * FROM usuarios WHERE username = '" + username + "' and contrasena = '" + contrasena + "'";
    try{
        Statement st = con.getConnection().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next()){
            String Nombre = rs.getString("Nombre");
            String Apellido = rs.getString("Apellido");
            String email = rs.getString("email");
            double cuenta_saldo = rs.getDouble("cuenta_saldo");
            boolean bonos = rs.getBoolean("bonos");
            usuarios usuario = new usuarios(username, contrasena, Nombre,  Apellido, email, cuenta_saldo, bonos);
            return gson.toJson(usuario);
        }
        
     }catch(Exception ex){
        System.out.print(ex.getMessage());
        
    }finally{
        con.desconectar();
    }
    
    return "false";
    
}

@Override
    public String registro(String username, String contrasena, String Nombre, String Apellido, String email, double cuenta_saldo, boolean bonos) {
      Gson gson = new Gson();
        DBConnection con = new DBConnection();
        
       
        String sql = "Insert into usuarios values('" + username + "', '" + contrasena + "', '" + Nombre + "', '" + Apellido + "', '" + email
                + "',  " + cuenta_saldo + ", " + bonos + ")";
        
        
        try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);
            usuarios usuario = new usuarios(username, contrasena, Nombre, Apellido, email, cuenta_saldo, bonos );
            st.close();
            return gson.toJson(usuario);
            
        
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            
        }finally{
            con.desconectar();
        }
        
        return "false";
        
        
    }

    @Override
    public String pedir(String username) {
        Gson gson= new Gson();
        DBConnection con = new DBConnection();
    
    String sql = "select * from usuario WHERE username = ' " + username + "'";
        
    
    try{
        Statement st = con.getConnection().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next()){
            String contrasena = rs.getString("Contrasena");
            String Nombre = rs.getString("Nombre");
            String Apellido = rs.getString("Apellido");
            String email = rs.getString("email");
            double cuenta_saldo = rs.getDouble("cuenta_saldo");
            boolean bonos = rs.getBoolean("bonos");
            usuarios usuario = new usuarios(username, contrasena,Nombre, Apellido, email, cuenta_saldo, bonos);
            return gson.toJson(usuario);
        }
        
     }catch(Exception ex){
        System.out.print(ex.getMessage());
        
    }finally{
        con.desconectar();
    }
    
    return "false";
    
}

    public String restarDinero(String username, double nuevoSaldo) {
        DBConnection con = new DBConnection();
        String sql = "Update usuarios set saldo = " + nuevoSaldo + " where username = '" + username + "'";

        try {

            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }

        return "false";
    }
    }

   
   
