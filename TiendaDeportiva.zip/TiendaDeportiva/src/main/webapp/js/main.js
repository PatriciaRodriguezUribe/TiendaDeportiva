var username = new URL(location.href).searchParams.get("username");
var user;

$(document).ready(function () {

$(function () {
$('[data-toggle = "tooltip"]').tooltip;
});
        getUsuario().then(function () {
            $("#mi-perfil-btn").atpr("href", "profile.html?username=" + username);
            $("#user-cuenta_saldo").html("$" + user.cuenta_saldo.toFixed(2))
     
           getRopa(false, "ASC");
     $("#ordenar-genero").click(ordenarRopa);
    });
})
});

aasync function getUsuario(){
    
    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioPedir",
        data: $.param({
            username: username
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);
            if (parsedResult != false) {
                user = parsedResult;
            } else {
                console.log("Error recuperando los datos del usuario");
            }
        }
    });
}



aasync function getRopa(){
    
    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletRopalistar",
        data: $.param({
            ordenar: ordenar,
            orden: orden
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);
            if (parsedResult != false) {
                mostrarRopaDisponible(parsedResult);
            } else {
                console.log("Error recuperando los datos de la ropa disponible")
            }
        }
    });
}

function mostrarRopaDisponible(ROPA) {
    let contenido = "";

        $.each(ROPA, function (index, ropa) {

            ropa = JSON.parse(ropa);
            let precio;

           contenido += '<tr><th scope="row">' + ropa.id_prenda + '</th>' +
                        '<td>' + ropa.tipo_prenda + '</td>' +
                        '<td>' + ropa.genero + '</td>' +
                        '<td>' + ropa.marca + '</td>' +
                        '<td>' + ropa.talla + '</td>' +
                        '<td>' + ropa.color + '</td>' +
                        '<td>' + ropa.estilo + '</td>' +
                        '<td>' + ropa.precio + '</td>' +
                        '<td><input type="checkbox" name="novedad" id="novedad' + ropa.id_prenda + '" disabled ';
               
                contenido += '></td>' +
                        '<td>' + precio + '</td>' +
                        '<td><button onclick="alquilarPelicula(' + ropa.id_prenda + ',' + precio + ');" class="btn btn-success" ';
                if (user.saldo < precio) {
                    contenido += ' disabled ';
                }

                contenido += '>Reservar</button></td></tr>'

            }
        });
        $("#Ropa-tbody").html(contenido);
    }

function ordenarRopa() {
        if ($("#icono-ordenar").hasClass("fa-sort")) {
            getRopa(true, "ASC");
            $("#icono-ordenar").removeClass("fa-sort");
            $("#icono-ordenar").addClass("fa-sort-down");
        } else if ($("#icono-ordenar").hasClass("fa-sort-down")) {
            getRopa(true, "DESC");
            $("#icono-ordenar").removeClass("fa-sort-down");
            $("#icono-ordenar").addClass("fa-sort-up");
        } else if ($("#icono-ordenar").hasClass("fa-sort-up")) {
            getRopa(false, "ASC");
            $("#icono-ordenar").removeClass("fa-sort-up");
            $("#icono-ordenar").addClass("fa-sort");
        }
    }
});

function PagarRopa(id_prenda, precio) {

    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletPagarRopa",
        data: $.param({
            id_prenda: id_prenda,
            username: username
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);
            if (parsedResult != false) {
                restarDinero(precio).then(function () {
                    location.reload();
                });

            } else {
                console.log("Error en la compra del articulo");
            }
        }
    });

}

async function restarDinero(precio) {

    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioRestarDinero",
        data: $.param({
            username: username,
            cuenta_saldo: parseFloat(user.cuenta_saldo - precio)
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);
            if (parsedResult != false) {
                console.log("Saldo actualizado")
            } else {
                console.log("Error en el proceso de pago");
            }
        }
    });
}

