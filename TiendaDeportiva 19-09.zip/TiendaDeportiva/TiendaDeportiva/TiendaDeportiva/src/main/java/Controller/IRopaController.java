
package Controller;


public interface IRopaController {
    
   public String listarRopa(boolean ordenar, String orden);
   public String Pagar(int id, String username);
    public String modificar(int id);
    public String devolver(int id, String username);
    public String sumarCantidad();
   
    
}
