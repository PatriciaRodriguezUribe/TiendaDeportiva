/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Beans.ropa;
import java.sql.ResultSet;
import java.sql.Statement;
import Conexion.DBConnection;
import com.google.gson.Gson;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RopaController implements IRopaController  {

    public String listarRopa(boolean ordenar, String orden) {
        Gson gson= new Gson();
     DBConnection con = new DBConnection();
    
    String sql = "SELECT * FROM Ropa LIMIT 100";
    
    if (ordenar== true){
        sql+= "ORDER BY tipo_prenda" + orden;
    }
    
    List <String> ROPA = new ArrayList<String>();
    try{
    
        Statement st = con.getConnection().createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next()){
            int id_prenda = rs.getInt("id_prenda");
            String tipo_prenda = rs.getString("tipo_prenda");
            String genero = rs.getString("genero");
            String marca = rs.getString("marca");
            String talla = rs.getString("talla");
            String color = rs.getString("color");
            String estilo = rs.getString("estilo");
            int precio = rs.getInt("precio");
            boolean disponible = rs.getBoolean("disponible");
            ropa Ropa = new ropa(id_prenda, tipo_prenda,genero, marca, talla, color,estilo, precio, disponible);
            ROPA.add(gson.toJson(Ropa));
        }
        
     }catch(Exception ex){
        System.out.print(ex.getMessage());
        
    }finally{
        con.desconectar();
    }
    
    return gson.toJson(ROPA);
    }

    public String restarDinero(String username, double nuevoSaldo) {
        DBConnection con = new DBConnection();
        String sql = "Update usuarios set saldo = " + nuevoSaldo + " where username = '" + username + "'";

        try {

            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }

        return "false";
    }
    
    public String pagar(int id, String username) {

        Timestamp fecha = new Timestamp(new Date().getTime());
        DBConnection con = new DBConnection();

        String sql = "Insert into pago values ('" + id + "', '" + username + "', '" + fecha + "')";

        try {

            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            String modificar = modificar(id);
            if (modificar.equals("true")) {
                return "true";
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
        } finally {
            con.desconectar();
        }
        return "false";

    }
    
    public String modificar(int id) {
        
        DBConnection con = new DBConnection();
        String sql = "Update ropa set copias = (copias - 1) where id = " + id;

        try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.toString());
        } finally {
            con.desconectar();
        }

        return "false";

    }

    @Override
    public String Pagar(int id, String username) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String devolver(int id, String username) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String sumarCantidad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
    
    

