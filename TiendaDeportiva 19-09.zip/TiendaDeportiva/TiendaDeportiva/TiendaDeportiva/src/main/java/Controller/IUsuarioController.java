package Controller;


public interface IUsuarioController  {
                   
    public String login(String username, String contrasena);
    public String registro(String username, String contrasena, String Nombre, String Apellido, String email, double cuenta_saldo, boolean bonos);
    public String pedir(String username);

            }